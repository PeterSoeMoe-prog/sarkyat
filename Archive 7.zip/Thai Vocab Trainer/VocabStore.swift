import Foundation

#if false
enum VocabStore {}
#endif
