import SwiftUI
import AVFoundation
import AudioToolbox
#if canImport(ConfettiSwiftUI)
import ConfettiSwiftUI
#endif

/// Simple daily quiz – shows 5 Thai vocab questions with three Burmese options each (one correct).
/// This is an **MVP placeholder**; scoring & persistence can be refined later.
struct DailyQuizView: View {
    // Speech handling
    private class SpeechDelegate: NSObject, AVSpeechSynthesizerDelegate {
        var onDone: (() -> Void)?
        func speechSynthesizer(_ s: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
            onDone?()
            onDone = nil
        }
    }
    private let speechDelegate = SpeechDelegate()
    private let synthesizer = AVSpeechSynthesizer()

    init() {
        synthesizer.delegate = speechDelegate
    }

    private func speakThai(_ text: String) {
        let utterance = AVSpeechUtterance(string: text)
        utterance.voice = AVSpeechSynthesisVoice(language: "th-TH")
        synthesizer.speak(utterance)
    }

    private func resumeSession() {
        @AppStorage("sessionPaused") var sessionPaused: Bool = false
        if sessionPaused {
            sessionPaused = false
            // Notify the counter view to resume
            NotificationCenter.default.post(name: .nextVocabulary, object: nil)
        }
    }

    private struct QuizQuestion: Identifiable {
        let id = UUID()
        let vocabID: UUID  // Track the vocabulary entry ID
        let thai: String
        let correctBurmese: String
        let options: [String]  // shuffled, contains correctBurmese
    }

    // MARK: - State
    @State private var questions: [QuizQuestion] = []
    @State private var currentIndex: Int = 0
    @State private var selectedAnswer: String? = nil
    @State private var score: Int = 0
    @State private var showResult: Bool = false
    @State private var currentQuestion: QuizQuestion? = nil
    @State private var confettiTrigger: Int = 0
    @State private var feedbackText: String? = nil
    @State private var timeRemaining: Int = 5
    @State private var timer: Timer? = nil
    // Quiz stats storage
    @AppStorage("quizDailyCount") private var quizDailyCount: Int = 0
    @AppStorage("quizWeeklyCount") private var quizWeeklyCount: Int = 0
    @AppStorage("quizMonthlyCount") private var quizMonthlyCount: Int = 0
    @AppStorage("quizTotalCount") private var quizTotalCount: Int = 0
    @AppStorage("quizLastDate") private var quizLastDate: Double = 0
    // Accuracy storage
    @AppStorage("correctDaily") private var correctDaily: Int = 0
    @AppStorage("attemptDaily") private var attemptDaily: Int = 0
    @AppStorage("correctWeekly") private var correctWeekly: Int = 0
    @AppStorage("attemptWeekly") private var attemptWeekly: Int = 0
    @AppStorage("correctMonthly") private var correctMonthly: Int = 0
    @AppStorage("attemptMonthly") private var attemptMonthly: Int = 0
    @AppStorage("correctTotal") private var correctTotal: Int = 0
    @AppStorage("attemptTotal") private var attemptTotal: Int = 0

    var body: some View {
        NavigationStack {
            ZStack {
            if questions.isEmpty {
                ProgressView().onAppear(perform: generateQuiz)
            } else if showResult {
                resultView
            } else {
                Group {
                    quizCard(for: questions[currentIndex])
                }
            }
                // Popup overlay - centered with higher zIndex
                if let fb = feedbackText {
                    ZStack {
                        // Semi-transparent background
                        Color.black.opacity(0.3)
                            .ignoresSafeArea()
                        
                        Text(fb)
                            .font(.system(size: 72, weight: .heavy))
                            .foregroundColor(fb == "TRUE" || fb == "TRUE" ? .green : .red)
                            .padding(.horizontal, 40)
                            .padding(.vertical, 20)
                            .background(
                                RoundedRectangle(cornerRadius: 20)
                                    .fill(Color(.systemBackground).opacity(0.95))
                            )
                            .shadow(radius: 20)
                    }
                    .zIndex(100)
                    .transition(.scale.combined(with: .opacity))
                }
            }
        }
        .onChange(of: currentIndex) { _ in
            // Restart the 5s countdown when the question index changes
            // Only when we're actively quizzing
            if !showResult && !questions.isEmpty {
                startTimer()
            }
        }
        .animation(.easeInOut(duration: 0.2), value: feedbackText)
        #if canImport(ConfettiSwiftUI)
                .confettiCannon(trigger: $confettiTrigger, 
                        num: 100, 
                        confettis: [.shape(.triangle), .shape(.circle)], 
                        colors: [.yellow, .orange], 
                        repetitions: 1, 
                        repetitionInterval: 0.1)
        #endif
        .withNotificationBell()
    }

    // MARK: - Views
    private func quizCard(for question: QuizQuestion) -> some View {
        VStack(spacing: 0) {
            // Progress indicator
            HStack(spacing: 8) {
                ForEach(0..<questions.count, id: \.self) { index in
                    RoundedRectangle(cornerRadius: 4)
                        .fill(index <= currentIndex ? Color.blue : Color.gray.opacity(0.3))
                        .frame(height: 6)
                }
            }
            .padding(.horizontal, 20)
            .padding(.top, 20)
            
            HStack {
                Text("Question \(currentIndex + 1) / \(questions.count)")
                    .font(.subheadline.weight(.medium))
                    .foregroundStyle(.secondary)
                
                Spacer()
                
                // Countdown timer
                HStack(spacing: 4) {
                    Image(systemName: "timer")
                        .font(.caption)
                    Text("\(timeRemaining)s")
                        .font(.subheadline.weight(.bold))
                        .monospacedDigit()
                }
                .foregroundColor(timeRemaining <= 2 ? .red : .blue)
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background(
                    RoundedRectangle(cornerRadius: 12)
                        .fill(timeRemaining <= 2 ? Color.red.opacity(0.1) : Color.blue.opacity(0.1))
                )
            }
            .padding(.horizontal, 20)
            .padding(.top, 12)

            Spacer()
            
            // Thai word card with speaker icon
            VStack(spacing: 12) {
                Text(question.thai)
                    .font(.system(size: 48, weight: .bold))
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 20)
                
                Button(action: {
                    speakThai(question.thai)
                }) {
                    HStack(spacing: 6) {
                        Image(systemName: "speaker.wave.2.fill")
                        Text("Tap to hear")
                            .font(.caption)
                    }
                    .foregroundColor(.blue)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 8)
                    .background(Color.blue.opacity(0.1))
                    .cornerRadius(20)
                }
            }
            .padding(.vertical, 40)
            .frame(maxWidth: .infinity)
            .background(
                RoundedRectangle(cornerRadius: 24)
                    .fill(Color(.secondarySystemGroupedBackground))
            )
            .padding(.horizontal, 20)
            .onAppear {
                // Auto-play Thai pronunciation after a brief delay
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    speakThai(question.thai)
                }
                // Start timer
                startTimer()
            }
            .onDisappear {
                stopTimer()
            }

            Spacer()

            VStack(spacing: 16) {
                ForEach(question.options, id: \.self) { option in
                    Button(action: {
                        // Play tap sound
                        playTapSound()
                        answerSelected(option, for: question)
                    }) {
                        HStack {
                            Text(option.isEmpty ? "—" : option)
                                .font(.system(size: 20, weight: .semibold))
                                .frame(maxWidth: .infinity, alignment: .center)
                            
                            if selectedAnswer != nil && option == question.correctBurmese {
                                Image(systemName: "checkmark.circle.fill")
                                    .font(.title2)
                                    .foregroundColor(.white)
                            }
                        }
                        .padding(.vertical, 18)
                        .padding(.horizontal, 20)
                        .background(
                            RoundedRectangle(cornerRadius: 16, style: .continuous)
                                .fill(
                                    selectedAnswer != nil && option == question.correctBurmese
                                        ? LinearGradient(colors: [.green, .mint], startPoint: .topLeading, endPoint: .bottomTrailing)
                                        : selectedAnswer != nil && option == selectedAnswer
                                            ? LinearGradient(colors: [.red, .orange], startPoint: .topLeading, endPoint: .bottomTrailing)
                                            : LinearGradient(colors: [.pink, .purple, .blue], startPoint: .topLeading, endPoint: .bottomTrailing)
                                )
                        )
                        .foregroundColor(.white)
                        .shadow(color: .black.opacity(0.1), radius: 8, y: 4)
                    }
                    .disabled(selectedAnswer != nil) // lock after choose
                    .scaleEffect(selectedAnswer != nil && option != question.correctBurmese && option != selectedAnswer ? 0.95 : 1.0)
                }
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 30)
            .animation(.spring(response: 0.3), value: selectedAnswer)

            Spacer()
        }
        .padding()
        .navigationTitle("Daily Quiz")
    }

    private var resultView: some View {
        VStack(spacing: 24) {
            Text("Daily Quiz")
                .font(.title)
            Text("Score: \(score) / \(questions.count)")
                .font(.largeTitle)
                .bold()
            VStack(spacing: 20) {
                NavigationLink(destination: ContentView()) {
                    Text("All Vocabs")
                        .font(.title3.bold())
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(
                            LinearGradient(colors: [.pink, .purple, .blue], startPoint: .topLeading, endPoint: .bottomTrailing)
                        )
                        .foregroundColor(.white)
                        .cornerRadius(16)
                        .shadow(radius: 6)
                }
                .padding(.horizontal, 30)
                
                // moved More Quiz button to bottom
                
                NavigationLink(destination: DailyStatView()) {
                    Text("See Stats")
                        .font(.title3.bold())
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(
                            LinearGradient(colors: [.pink, .purple, .blue], startPoint: .topLeading, endPoint: .bottomTrailing)
                        )
                        .foregroundColor(.white)
                        .cornerRadius(16)
                        .shadow(radius: 6)
                }
                .padding(.horizontal, 30)
                
                Button(action: {
                    // Resume the counter/boost session
                    resumeSession()
                    playTapSound()
                }) {
                    HStack {
                        Image(systemName: "play.circle.fill")
                            .imageScale(.medium)
                        Text("Resume Study")
                    }
                    .font(.title3.bold())
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(
                        LinearGradient(colors: [.pink, .purple, .blue], startPoint: .topLeading, endPoint: .bottomTrailing)
                    )
                    .foregroundColor(.white)
                    .cornerRadius(16)
                    .shadow(radius: 6)
                }
                .padding(.horizontal, 30)
                
                Button(action: {
                    // Reset the quiz state and start again
                    self.showResult = false
                    self.score = 0
                    self.currentIndex = 0
                    self.selectedAnswer = nil
                    self.generateQuiz()
                    playTapSound()
                }) {
                    Text("More Quiz")
                        .font(.title3.bold())
                        .frame(maxWidth: .infinity, minHeight: 56)
                        .background(
                            LinearGradient(colors: [.pink, .purple, .blue], startPoint: .topLeading, endPoint: .bottomTrailing)
                        )
                        .foregroundColor(.white)
                        .cornerRadius(16)
                        .shadow(radius: 6)
                }
                .padding(.horizontal, 30)
            }
            .onAppear {
                // Trigger confetti and sound when result page appears
                confettiTrigger += 1
                AudioServicesPlaySystemSound(1025) // Congrat sound
                // Save quiz stats to CSV
                let stat = QuizStat(
                    date: Date(),
                    quizType: "thai to burmese",
                    score: score,
                    totalQuestions: questions.count,
                    correctAnswers: score
                )
                QuizStatsManager.shared.append(stat: stat)
            }
        }
    }

    // MARK: - Logic
    private func generateQuiz() {
        let items = loadCSV().filter { 
            !($0.burmese ?? "").isEmpty && $0.category?.lowercased() != "vulger"
        }
        guard items.count >= 3 else { return }

        var qs: [QuizQuestion] = []
        let pool = items.shuffled()

        for item in pool.prefix(5) {
            let correct = item.burmese ?? ""
            let correctLen = correct.count
            // Try to find distractors of similar length (±30%)
            var distractors = items.compactMap { $0.burmese }
                .filter { $0 != correct && abs($0.count - correctLen) <= max(2, Int(Double(correctLen) * 0.3)) }
                .shuffled().prefix(2)

            // If not enough, relax to ±50%
            if distractors.count < 2 {
                distractors = items.compactMap { $0.burmese }
                    .filter { $0 != correct && abs($0.count - correctLen) <= max(3, Int(Double(correctLen) * 0.5)) }
                    .shuffled().prefix(2)
            }
            // If still not enough, just pick any that aren't the correct answer
            if distractors.count < 2 {
                distractors = items.compactMap { $0.burmese }
                    .filter { $0 != correct }
                    .shuffled().prefix(2)
            }

            var opts = Array(distractors)
            opts.append(correct)
            opts.shuffle()
            qs.append(QuizQuestion(vocabID: item.id, thai: item.thai, correctBurmese: correct, options: opts))
        }
        self.questions = qs
    }

    private func answerSelected(_ option: String, for question: QuizQuestion) {
        stopTimer() // Stop the countdown
        let isCorrect = option == question.correctBurmese
        feedbackText = isCorrect ? "TRUE" : "FALSE"
        selectedAnswer = option
        
        // Play sound based on answer correctness
        if !isCorrect {
            SoundManager.playSound(1052) // Play sound for wrong answer
            
            // Schedule notification for failed quiz question
            NotificationEngine.shared.scheduleFailedQuizNotification(
                vocabID: question.vocabID,
                thaiWord: question.thai,
                burmeseTranslation: question.correctBurmese
            )

            // If this vocab was previously "Ready", downgrade back to "Drill"
            downgradeReadyToDrill(for: question.vocabID, thai: question.thai)
        }
        
        if option == question.correctBurmese {
            score += 1
            // Play cheer sound after 0.25s delay for correct answer
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
                SoundManager.playSound(1025) // Cheer sound for correct answer
            }
        }
        // proceed to next after brief delay
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
            feedbackText = nil
            selectedAnswer = nil
            if currentIndex + 1 < questions.count {
                currentIndex += 1
                // Play Thai pronunciation for the next question
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    self.speakThai(self.questions[currentIndex].thai)
                }
            } else {
                updateQuizStats(correct: score, attempts: questions.count)
                showResult = true
            }
        }
    }

    // MARK: - Stats update
    // MARK: - Sound
    private func playTapSound() {
        #if os(iOS)
        AudioServicesPlaySystemSound(1104) // tap pop
        #endif
    }

    private func updateQuizStats(correct: Int = 0, attempts: Int = 0) {
        let now = Date()
        let cal = Calendar.current
        let last = Date(timeIntervalSince1970: quizLastDate)
        // Reset counters when boundaries passed
        if !cal.isDate(now, inSameDayAs: last) {
            quizDailyCount = 0
            correctDaily = 0
            attemptDaily = 0
        }
        if cal.component(.weekOfYear, from: now) != cal.component(.weekOfYear, from: last) ||
            cal.component(.yearForWeekOfYear, from: now) != cal.component(.yearForWeekOfYear, from: last) {
            quizWeeklyCount = 0
            correctWeekly = 0
            attemptWeekly = 0
        }
        if cal.component(.month, from: now) != cal.component(.month, from: last) ||
            cal.component(.year, from: now) != cal.component(.year, from: last) {
            quizMonthlyCount = 0
            correctMonthly = 0
            attemptMonthly = 0
        }
        // Increment quiz session counts
        quizDailyCount += 1
        quizWeeklyCount += 1
        quizMonthlyCount += 1
        quizTotalCount += 1
        // Increment accuracy counts
        correctDaily += correct
        attemptDaily += attempts
        correctWeekly += correct
        attemptWeekly += attempts
        correctMonthly += correct
        attemptMonthly += attempts
        correctTotal += correct
        attemptTotal += attempts
        quizLastDate = now.timeIntervalSince1970
    }

    private func buttonColor(option: String, question: QuizQuestion) -> Color {
        guard let selected = selectedAnswer else { return Color(.systemGray6) }
        if option == question.correctBurmese {
            return option == selected ? .green.opacity(0.4) : .green.opacity(0.15)
        } else if option == selected {
            return .red.opacity(0.4)
        } else {
            return Color(.systemGray6)
        }
    }
    
    // MARK: - Timer Functions
    private func startTimer() {
        timeRemaining = 5
        stopTimer() // Clear any existing timer
        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
            if timeRemaining > 0 {
                timeRemaining -= 1
            } else {
                // Time's up - auto-select wrong answer
                handleTimeout()
            }
        }
    }
    
    private func stopTimer() {
        timer?.invalidate()
        timer = nil
    }
    
    private func handleTimeout() {
        stopTimer()
        // Mark as wrong answer (no selection)
        let question = questions[currentIndex]
        selectedAnswer = "" // Empty selection indicates timeout
        
        // Show feedback
        feedbackText = "TIME'S UP"
        AudioServicesPlaySystemSound(1053) // Error sound
        
        // Schedule notification for failed word
        NotificationEngine.shared.scheduleFailedQuizNotification(
            vocabID: question.vocabID,
            thaiWord: question.thai,
            burmeseTranslation: question.correctBurmese
        )
        // Downgrade Ready -> Drill on timeout as well
        downgradeReadyToDrill(for: question.vocabID, thai: question.thai)
        
        // Move to next question after delay
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            feedbackText = nil
            selectedAnswer = nil
            if currentIndex + 1 < questions.count {
                currentIndex += 1
            } else {
                showResult = true
                updateQuizStats(correct: score, attempts: questions.count)
            }
        }
    }

    // MARK: - Downgrade Ready -> Drill when a quiz is failed
    private func downgradeReadyToDrill(for id: UUID, thai: String) {
        // Load persisted items
        var items: [VocabularyEntry] = []
        if let data = UserDefaults.standard.data(forKey: "vocab_items"),
           let decoded = try? JSONDecoder().decode([VocabularyEntry].self, from: data) {
            items = decoded
        }
        // Try by ID first
        var idx = items.firstIndex { $0.id == id }
        // Fallback: match by normalized Thai text (in case IDs differ)
        if idx == nil {
            let norm: (String) -> String = { s in
                s.folding(options: [.diacriticInsensitive, .caseInsensitive, .widthInsensitive], locale: .current)
            }
            let target = norm(thai)
            idx = items.firstIndex { norm($0.thai) == target }
        }
        guard let found = idx else { return }
        if items[found].status == .ready {
            items[found].status = .drill
            // Persist back
            if let data = try? JSONEncoder().encode(items) {
                UserDefaults.standard.set(data, forKey: "vocab_items")
            }
            // Notify live views to update if they are visible
            NotificationCenter.default.post(name: Notification.Name("vocabStatusChanged"), object: items[found].id)
        }
    }
}

#Preview {
    DailyQuizView()
}
