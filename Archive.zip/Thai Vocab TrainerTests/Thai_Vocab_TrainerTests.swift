//
//  Thai_Vocab_TrainerTests.swift
//  Thai Vocab TrainerTests
//
//  Created by Peter on 6/24/25.
//

import Testing
@testable import Thai_Vocab_Trainer

struct Thai_Vocab_TrainerTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
